using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace RehberCB.Models.Entities
{
    [Table("Kisiler")]
    public class Kisi
    {
        public int Id { get; set; }
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public string? EvTelefon { get; set; } 
        public string CepTelefon { get; set; }
        public string EmailAdres { get; set; }
        
        public string Adres { get; set;}  
        [ForeignKey("Departman")]
        public int DepartmanId{ get; set;}
       public Departman Departman { get; set; }



    }
}