using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RehberCB.Models.Entities;

namespace RehberCB.Models.KisiModel
{
    public class KisiDetayViewModel
    {
      public Kisi Kisi { get; set; } 
      public List<Departman> Departmanlar {get; set;} 
    }
}
