using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Web;
using RehberCB.Models.Entities;

namespace RehberCB.Models.Context;
public class MvcRehberContext:DbContext
{
    private readonly IConfiguration _configuration;

    public MvcRehberContext(DbContextOptions optionsBuilder, IConfiguration configuration)
         :base(optionsBuilder)
    {
        _configuration = configuration;
    }

    protected override void OnConfiguring(DbContextOptionsBuilder options)
    {
        // Console.WriteLine(Configuration.GetConnectionString("DefaultConnectionPQ"));
        // connect to postgres with connection string from app settings
        // options.UseNpgsql(connectionString: _configuration.GetConnectionString("DefaultConnection"));
    }

    public DbSet<Kisi> Kisiler { get; set; }
    public DbSet<Departman> Departmanlar { get; set; }

}
