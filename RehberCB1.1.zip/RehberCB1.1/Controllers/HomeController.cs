using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RehberCB.Models;
using RehberCB.Models.Context;
using RehberCB.Models.Entities;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RehberCB.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly MvcRehberContext _context;

        public HomeController(ILogger<HomeController> logger, MvcRehberContext context)
        {
            _logger = logger;
            _context = context;
        }

        // Index action methodu
        public async Task<IActionResult> Index()
        {
            var contacts = await _context.Kisiler.Include(k => k.Departman).ToListAsync();
            return View(contacts);
        }

        // Ad ile filtreleme için yeni bir action method
        public async Task<IActionResult> FilterContactsByAd(string search)
        {
            var query = _context.Kisiler.Include(k => k.Departman).AsQueryable();

            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(c => c.Ad.Contains(search));
            }

            var contacts = await query.ToListAsync();
            return PartialView("_ContactsTable", contacts);
        }

        // Rehberi indir action methodu
        public async Task<IActionResult> Download()
        {
            try
            {
                // Veritabanından tüm kişileri ve departman bilgilerini al
                var contacts = await _context.Kisiler.Include(c => c.Departman).ToListAsync();
                
                // CSV içeriğini oluştur
                var csv = new StringBuilder();
                csv.AppendLine("Ad,Soyad,Cep Telefonu,EmailAdres,Departman");

                foreach (var contact in contacts)
                {
                    var departmanAdi = contact.Departman != null ? contact.Departman.DepartmanAdi : "Belirtilmemiş";
                    csv.AppendLine($"{contact.Ad},{contact.Soyad},{contact.CepTelefon},{contact.EmailAdres},{departmanAdi}");
                }

                // CSV verilerini byte dizisine çevir
                var bytes = Encoding.UTF8.GetBytes(csv.ToString());
                var stream = new MemoryStream(bytes);

                // Dosyayı kullanıcıya gönder
                return File(stream, "text/csv", "Rehber.csv");
            }
            catch (Exception ex)
            {
                // Hata durumunda loglama ve kullanıcıya bilgi verme
                _logger.LogError(ex, "Rehber indirirken bir hata oluştu.");
                return StatusCode(500, "İç Sunucu Hatası: Rehber indirilemedi.");
            }
        }

        // Diğer action metodları...
    }
}
