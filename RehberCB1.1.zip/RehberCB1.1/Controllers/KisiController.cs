using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RehberCB.Models.Context;
using RehberCB.Models.Entities;
using RehberCB.Models.KisiModel;

namespace RehberCB.Controllers
{
    public class KisiController : Controller
    {
        MvcRehberContext db;
        public KisiController(MvcRehberContext context)
        {
            db = context;
        }

        public ActionResult Index()
        {  
            //veritabanındaki verileri cekecegiz.
            if(db != null){
             var kisiler =db.Kisiler.Include(x=>x.Departman).ToList();
            return View(kisiler);
            }
            return View(new List<Kisi>());
           
        }

        [HttpGet]
        //ekle sayfasını  açmamız için asagıdaki kodu kullanacağız.
        public ActionResult Ekle()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Ekle(Kisi kisi)
        {
        try
        {
            
            db.Kisiler.Add(kisi);
            db.SaveChanges();

            TempData["BasariliMesaj"]="Kişi Eklme İşlemi Başarıyla Gerçeklişti.";

        }
        catch (System.Exception)
        {
            TempData["HataliMesaj"]="Kişi Eklerken Hata Oluştu Lütfen Yeniden Deneyiniz.";
            throw;
        }

            return RedirectToAction("Index");
        }
        
        [HttpGet]
        public ActionResult Guncelle(int id)
        {
            var kisi = db.Kisiler.Find(id);

            if (kisi == null)
            {
                TempData["HataliMesaj"]="Güncellenmek İstenen kayıt bulunamadı!";
                return RedirectToAction("Index");
            }
            return View(kisi);
        }

        [HttpPost]
        public ActionResult Guncelle(Kisi kisi)
        {
            var eskiKisi = db.Kisiler.Find(kisi.Id);

            if (eskiKisi==null)
            {
                TempData["HataliMesaj"]="Güncellenmek İstenen kayıt bulunamadı!";
                return RedirectToAction("Index");
            }

            eskiKisi.Ad = kisi.Ad;
            eskiKisi.Soyad = kisi.Soyad;
            eskiKisi.EvTelefon = kisi.EvTelefon;
            eskiKisi.CepTelefon = kisi.CepTelefon;
            eskiKisi.Adres = kisi.Adres;
            eskiKisi.EmailAdres = kisi.EmailAdres;
            eskiKisi.Departman = kisi.Departman;
            eskiKisi.DepartmanId = kisi.DepartmanId;
            

            //Güncellenen verileri veri tabanına kayıt etmek için asagıdaki kodu kullanıyoruz.
            db.SaveChanges();


            TempData["BasariliMesaj"]="Kişi Bilgileri Başarıyla Güncellendi.";

            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Detay(int id)
        {
            var kisi = db.Kisiler.Find(id);

            if (kisi == null)
            {
                TempData["HataliMesaj"]="Kişi bulunamadı!";
                return RedirectToAction("Index");
            }
            var model = new KisiDetayViewModel
            {
            Kisi=kisi,
            Departmanlar = db.Departmanlar.ToList()
            };

            return View(model);
        }

        public ActionResult Sil(int id)
        {
            var kisi = db.Kisiler.Find(id);

            if (kisi==null)
            {
                 TempData["HataliMesaj"]="Kişi bulunamadı!";
                return RedirectToAction("Index");
            }

            db.Kisiler.Remove(kisi);
            db.SaveChanges();

            TempData["BasariliMesaj"]="Kişi Veritabanından Silinmiştir.🧹";

            
            return RedirectToAction("Index");
        }
    }
}