using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging.Console;
using RehberCB.Models;
using RehberCB.Models.Context;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<MvcRehberContext>(options => 
{
    options.UseNpgsql(
        connectionString,
        npgsqlOptionsAction: sqlOptions => 
        {
            if (builder.Environment.IsDevelopment())
            {
                sqlOptions.CommandTimeout(100);
            }
        }
    );
    if (builder.Environment.IsDevelopment())
    {
        options
            .EnableSensitiveDataLogging(true)
            .EnableDetailedErrors(true)
            .UseLoggerFactory(
                LoggerFactory.Create(loggingBuilder => 
                    loggingBuilder.AddConsole(configure => 
                        new SimpleConsoleFormatterOptions
                        {
                            ColorBehavior = LoggerColorBehavior.Disabled,
                            IncludeScopes = false,
                            SingleLine = false
                        }
                    )
                )
            );
    }   
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// CSV dosyası indirme endpoint'i
app.MapGet("/api/contacts/download", async (MvcRehberContext context) =>
{
    var contacts = await context.Kisiler.ToListAsync(); // Veritabanından verileri çekiyoruz

    var csv = new StringBuilder();
    csv.AppendLine("Id,Name,Email");

    foreach (var contact in contacts)
    {
        csv.AppendLine($"{contact.Id},{contact.Ad},{contact.Soyad},{contact.EvTelefon},{contact.CepTelefon},{contact.Adres},{contact.EmailAdres}");
    }

    var bytes = Encoding.UTF8.GetBytes(csv.ToString());
    var output = new MemoryStream(bytes);

    return Results.File(output, "text/csv", "contacts.csv");
});

app.Run();

// Contact model
namespace RehberCB.Models
{
    public class Contact
    {
        public int Id { get; set; }
        public string Ad { get; set; }
        public string Soyad { get; set; }
         public string EvTelefon { get; set; }
         public string CepTelefon { get; set; }
         public string EmaiAdres { get; set; }
          public string Adres { get; set; }
    }
}

